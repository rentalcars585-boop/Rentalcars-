RENTAL CAR WEBSITE — MANGALORE

Files:
- index.html
- style.css
- script.js
- assets/logo.jpg (your supplied logo)

Add your real car photos:
1. Put a photo of your Maruti Suzuki Fronx in assets/ and name it fronx.jpg
2. Put a photo of your Hyundai Exter in assets/ and name it exter.jpg
3. Keep the filenames exactly as shown.

Run:
- Keep the folder structure unchanged.
- Open index.html in a browser, or open the folder in VS Code and use Live Server.

Already included:
- Your logo
- Mangalore location
- Phone number +91 90199 53708
- WhatsApp enquiry links for both cars
- Responsive dark luxury layout

Before publishing, confirm your rental terms, availability, and any prices you want to display.
